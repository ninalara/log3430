#!/bin/bash

pip3 install --user -U nltk
python3 -m nltk.downloader stopwords